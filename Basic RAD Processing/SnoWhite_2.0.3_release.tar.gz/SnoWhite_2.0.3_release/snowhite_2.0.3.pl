################# 
# snowhite_2.0.x.pl
# Pipeline to clean and trim DNA sequences
#
# Copyright (C) 2011 Katrina M Dlugosch
# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
# Disclaimer: Apologies for (inevitable) bad programming form; this code was written by a biologist.
#
# Run: perl snowhite_2.0.x.pl [OPTIONS]
#
#################


#!usr/bin/perl
use strict;
use File::Spec;
use Getopt::Std;
use List::Util qw[min max];
use Cwd;


#===== INPUTS =====
my $dir = getcwd;
my %opts; getopt('abBcdDEfghijklLmnopqQrRstuvwYz', \%opts ); #Unused lc: exy

my $usage = "\n\tUsage Error\n\tFor help type:  perl snowhite_2.0.2.pl -help\n\n";
my $help = "\n\tUsage Help: 
	Run: perl snowhite_2.0.x.pl [OPTIONS]

	OPTIONS =
	Files:
	-f: <FILENAME> fasta or fastq sequences (specify path if needed)
	-q: <FILENAME> quality file (optional, fasta only)
	-v: <FILENAME> vector/primer/adapter file (optional)
	-s: <FILENAME> internal/long contaminants file (optional, SeqClean step only)

	Output settings:
	-o: <FILENAME> name for new output folder and file prefixes (default = sequence input filename)
	-m: <integer> minimum sequence length for cleaned reads (default = 50bp, APPLIES TO -Q,-E,-L,-Y STEPS, NOT to -B,-D,-R)
	-g: <T/F> delete all temporary (garbage) files (default = F)	
	-R: <T/F> convert final output to fastq format (default = F, i.e. fasta format)

	File splitting (fastq only):
	-B: <integer/FILENAME> split file into set number of subfiles, or according to barcodes in FILENAME (default = no splitting)
	-j: <5/3> look for barcodes at 5' or 3' ends (default = 5)
	-z: <integer> number of mismatches allowed when matching barcode (default = 0) 

	Quality trimming:
	-Q: <integer> minimum phred score under which to trim 3' ends (default = no trimming; suggest = 10)

	End clipping:
	-E: <5/3/B/FILENAME> clip at 5', 3', Both, or according to sequences in FILENAME (default = 5)
	-c: <integer> number of bases to clip off of all sequences (unless -E is FILENAME; default = 0)
	
	TagDust read filtering (for multimers of sequences in -v):
	-D: <T/F> execute TagDust, assuming primer/adapter (-v) file is provided (default = F)
	-d: <decimal> false discovery rate (default = 0.01)

	SeqClean trimming (for uninformative bases and matches to sequences in -v and -s):
	-L: <T/F> execute SeqClean (default = F)
	-p: <integer> processor number (optional, default = 1)

	Terminal poly trimming (e.g. 3'AAAAAAAAAACGATTAG...):
	-Y: <T/F> execute poly trimming as defined by all following parameters (default = F)
	-l: <integer> minimum length of terminal A/T repeat (default = 6)
	-a: <3/5/B> poly A at 3', 5', or Both ends (default = 3)
	-t: <3/5/B> poly T at 3', 5', or Both ends (default = 5)

	Terminal poly trimming inside of cap (e.g. 3'CGAAAAAAAAAAAACGATTAG...):
	-b: <integer> number of terminal bases to look beyond for start of terminal poly A/T (default = 0)
	-r: <integer> minimum length of A/T repeat inside of -b to consider as poly A/T (min = 2, default = 10)

	Internal poly trimming (e.g. 3'...CCGTATAGGAAAAAAAAAAAAAAAAAAAACGATTAGGG...5'):
	-i: <integer> minimum length of internal poly A/T sequence to consider as poly A/T (default = 100bp, extreme case)
	-k: <T/F> keep the longer end of sequence broken by a single internal polyA/T (default = F)

	General poly trimming settings:
	-n: <T/F> interpret Ns within A/T repeats as As or Ts (default = T)
	-w: <T/F> allow wobble: i.e. ignore single alternative bases within A/T repeats (default = T)

	EXAMPLE: perl snowhite_2.0.x.pl -f myfasta -q myfasta.qual -v myprimers -Q T -D T -L T -Y T -i 20 -o mytestrun1\n\n";

# Help
if ($opts{h} ne "") { die "\n\tInput <h>$help";}
foreach my $switch (keys %opts) { unless ($switch =~ m/[abBcdDEfghijklLmnopqQrRstuvwYz]/) { die "\n\tInput <$switch>$usage";}}

# Files:
my ($INFILE, $INPATH);
if ($opts{f} ne "") { 
	$INPATH = "$opts{f}";
	if (-e "$opts{f}") {
		print "\nSequence file found...";
		my @filepath = File::Spec->splitpath($opts{f}); 
		$INFILE = $filepath[2];
	}
	else { die "\n\tError: Input file <$INPATH> not found.\n\tInput <f>$usage"; }
}
else { die "\n\tInput <f> required$usage"; }
 
my ($QUALFILE, $QUALPATH);
if ($opts{q} ne "") {
	$QUALPATH = "$opts{q}";
	if (-e "$opts{q}") {
		print "\nQuality file found...";
		my @filepath = File::Spec->splitpath($opts{q}); 
		$QUALFILE = $filepath[2];
	}
	else { die "\n\tError: Quality file <$QUALPATH> not found.\n\tInput <q>$usage"; }
}
else { $QUALPATH = 'none'; print "\nNo quality file given..."; }

my ($VECTORFILE, $VECTORPATH);  
if ($opts{v} ne "") { 
	$VECTORPATH = "$opts{v}";
	if (-e "$opts{v}") {
		print "\nPrimer/adapter file found...";
		my @filepath = File::Spec->splitpath($opts{v}); 
		$VECTORFILE = $filepath[2];
	}
	else { die "\n\tError: Primer file <$VECTORPATH> not found.\n\tInput <v>$usage"; }
}
else { $VECTORPATH = 'none'; print "\nNo primer/adapter file given. Adapter searches will be skipped..."; }


my ($CONTAMFILE, $CONTAMPATH);  
if ($opts{s} ne "") { 
	$CONTAMPATH = "$opts{s}";
	if (-e "$opts{s}") {
		print "\nContaminant file found...";
		my @filepath = File::Spec->splitpath($opts{s}); 
		$CONTAMFILE = $filepath[2];
	}
	else { die "\n\tError: Contaminant file <$CONTAMPATH> not found.\n\tInput <s>$usage"; }
}
else { $CONTAMPATH = 'none'; print "\nNo contaminant file given. Contaminant searches will be skipped..."; }


# Output settings
my ($OUTFILE, $OUTQ);
if ($opts{o} ne "") { 
	$OUTFILE = "$opts{o}"; 
	my @filepath = File::Spec->splitpath($opts{o}); 
	if ($OUTFILE ne $filepath[2]) { die "\n\tError: Sorry, output filename <$OUTFILE> cannot include a directory.\n\n"; }
}
else { $OUTFILE = $INFILE; $OUTFILE =~ s/\..*$//; }

my $MINLENGTH;
if ($opts{m} ne "") { if ($opts{m} =~ m/^\d+$/) { if (int($opts{m}) eq $opts{m}) { $MINLENGTH = "$opts{m}"; } else { die "\n\tInput <m>$usage"; }} else { die "\n\tInput <m>$usage"; } }
else { $MINLENGTH = 50; }

my $DELG;
if ($opts{g} ne "") { if ( ($opts{g} eq 'T') || ($opts{g} eq 'F') ) { $DELG = "$opts{g}"; } else {die "\n\tInput <g>$usage";} }  
else { $DELG = 'F'; }

if ($opts{R} ne "") { if ( ($opts{R} eq 'T') || ($opts{R} eq 'F') ) { $OUTQ = "$opts{R}"; } else {die "\n\tInput <R>$usage";} }  
else { $OUTQ = 'F'; }


# File splitting
my $SPLIT;
my $SPLITFILE = 'N';
if ($opts{B} ne "") { 
	if ($opts{B} =~ m/^\d+$/) { if (int($opts{B}) eq $opts{B}) {$SPLIT = "$opts{B}";} else {die "\n\tInput <B>$usage";}}
	elsif (-e "$opts{B}") { $SPLIT = "$opts{B}";  $SPLITFILE = 'Y'; }
	else {die "\n\tInput <B>$usage";}
}
else { $SPLIT = 'F'; };

my $LOOKJ;
if ($opts{j} ne "") { if ( ($opts{j} eq '3') || ($opts{j} eq '5') ) { $LOOKJ = "$opts{j}"; } else {die "\n\tInput <j>$usage";} }  
else { $LOOKJ = '5'; }

my $BMIS;
if ($opts{z} ne "") { if ($opts{z} =~ m/^\d+$/) { if (int($opts{z}) eq $opts{z}) { $BMIS = "$opts{z}"; } else { die "\n\tInput <z>$usage"; }} else { die "\n\tInput <z>$usage"; } }
else { $BMIS = 0; }

if ($SPLITFILE eq 'N' && ($opts{j} ne "" || $opts{z} ne "") ) {die "\n\tError: Barcode parsing settings require (-B FILENAME)\n\n";}


# Quality trimming inputs
my $QUALMIN;
if ($opts{Q} ne "") { if ($opts{Q} =~ m/^\d+$/) { if (int($opts{Q}) eq $opts{Q}) { $QUALMIN = "$opts{Q}"; } else { die "\n\tInput <Q>$usage"; }} else { die "\n\tInput <Q>$usage"; } }
else { $QUALMIN = 'F'; }


# Adapter clipping
my $CLIP;
if ($opts{c} ne "") { if ($opts{c} =~ m/^\d+$/) { if (int($opts{c}) eq $opts{c}) { $CLIP = "$opts{c}"; } else { die "\n\tInput <c>$usage"; }} else { die "\n\tInput <c>$usage"; } }
else { $CLIP = 0; }

my $CLIPSET;
my $CLIPFILE = 'N';
if ($opts{E} ne "") { 
	if ( ($opts{E} eq '3') || ($opts{E} eq '5') || ($opts{E} eq 'B') ) { if ($CLIP == 0) {die "\n\tError: Set clipping length (-c)\n\n";}  else {$CLIPSET = "$opts{E}";}}
	elsif (-e "$opts{E}") { if ($CLIP != 0) { die "\n\tError: Use clipping file in -E or clipping length (-c)??\n\n"; } else { $CLIPSET = "$opts{E}";  $CLIPFILE = 'Y'; }}
	else { die "\n\tInput <E>$usage";  }
}
else { $CLIPSET = '5'; };


# TagDust inputs:
my $USETAG;
if ($opts{D} ne "") { if ( ($opts{D} eq 'T') || ($opts{D} eq 'F') ) { $USETAG = "$opts{D}"; } else {die "\n\tInput <D>$usage";} }  
else { $USETAG = 'F'; }
if ($USETAG eq 'T' && $VECTORPATH eq 'none') {die "\n\tError: A primer/adapter file (-v) is required for TagDust\n\n";}

my $FDR;
if ($opts{d} ne "") { if ($opts{d} =~ m/^\d+[\/|\.]\d+$/) { $FDR = "$opts{d}"; } else {die "\n\tInput <d>$usage";} }  else { $FDR = "0.01"; }
if ($opts{d} && $USETAG eq 'F') {die "\n\tError: Input for -d requires TagDust used (-D T)\n\n";}


# Seqclean inputs
my $USESEQ;
if ($opts{L} ne "") { if ( ($opts{L} eq 'T') || ($opts{L} eq 'F') ) { $USESEQ = "$opts{L}"; } else {die "\n\tInput <L>$usage";} }  
else { $USESEQ = 'F'; }
if ($opts{s} ne "" && $USESEQ eq 'F') {die "\n\tError: Internal contaminants (-s) only used with SeqClean (-L T)\n\n";}

my $PROCESSORS;
if ($opts{p} ne "") { if ($opts{p} =~ m/^\d+$/) { if (int($opts{p}) eq $opts{p}) { $PROCESSORS = "$opts{p}"; } else { die "\n\tInput <p>$usage"; } } else { die "\n\tInput <p>$usage"; } }
else { $PROCESSORS = 1; }
if ($opts{p} ne "" && $USESEQ eq 'F') {die "\n\tError: Processor number (-p) only used with SeqClean (-L T)\n\n";}


# Terminal repeat inputs:
my $USEPOLY;
if ($opts{Y} ne "") { if ( ($opts{Y} eq 'T') || ($opts{Y} eq 'F') ) { $USEPOLY = "$opts{Y}"; } else {die "\n\tInput <Y>$usage";} }  
else { $USEPOLY = 'F'; }

my $POLYLENGTH;
if ($opts{l} ne "") { if ($opts{l} =~ m/^\d+$/) { if (int($opts{l}) eq $opts{l}) { $POLYLENGTH = "$opts{l}"; } else { die "\n\tInput <l>$usage"; }} else { die "\n\tInput <l>$usage"; } }
else { $POLYLENGTH = 6; }

my ($LOOKA);
if ($opts{a} ne "") { if ( ($opts{a} eq '3') || ($opts{a} eq '5') || ($opts{a} eq 'B') ) { $LOOKA = "$opts{a}"; } else {die "\n\tInput <a>$usage";} }  
else { $LOOKA = '3'; }

my ($LOOKT);
if ($opts{t} ne "") { if ( ($opts{t} eq '3') || ($opts{t} eq '5') || ($opts{t} eq 'B') ) { $LOOKT = "$opts{t}"; } else {die "\n\tInput <t>$usage";} }  
else { $LOOKT = '5'; }


# Terminal repeats inside of cap inputs:
my $CAPLENGTH;  
if ($opts{b} ne "") { if ($opts{b} =~ m/^\d+$/) { if (int($opts{b}) eq $opts{b}) { $CAPLENGTH = "$opts{b}"; } else { die "\n\tInput <b>$usage"; }} else { die "\n\tInput <b>$usage"; } }
else { $CAPLENGTH = 0; }

my $INSIDECAP;
if ($opts{r} ne "") { if ($opts{r} =~ m/^\d+$/) { if ((int($opts{r}) eq $opts{r}) && ($opts{r} >= 2)) { $INSIDECAP = "$opts{r}"; } else { die "\n\tInput <r>$usage"; }} else { die "\n\tInput <r>$usage"; } }
else { $INSIDECAP = 10; }


# Internal repeats inputs:
my $INSIDEMAX;
if ($opts{i} ne "") { if ($opts{i} =~ m/^\d+$/) { if (int($opts{i}) eq $opts{i}) { $INSIDEMAX = "$opts{i}"; } else { die "\n\tInput <i>$usage"; }} else { die "\n\tInput <i>$usage"; } }
else { $INSIDEMAX = 100; }

my $KEEPFRAG;
if ($opts{k} ne "") { if ( ($opts{k} eq 'T') || ($opts{k} eq 'F') ) { $KEEPFRAG = "$opts{k}"; } else {die "\n\tInput <k>$usage";} }  
else { $KEEPFRAG = 'F'; }


# General poly trimming setting inputs:
my $NBAD;
if ($opts{n} ne "") { if ( ($opts{n} eq 'T') || ($opts{n} eq 'F') ) { $NBAD = "$opts{n}"; } else {die "\n\tInput <n>$usage";} }  
else { $NBAD = 'T'; }

my $WBAD;
if ($opts{w} ne "") { if ( ($opts{w} eq 'T') || ($opts{w} eq 'F') ) { $WBAD = "$opts{w}"; } else {die "\n\tInput <w>$usage";} }  
else { $WBAD = 'T'; }

if ($USEPOLY eq 'F' && ($opts{l}||$opts{a}||$opts{t}||$opts{b}||$opts{r}||$opts{i}||$opts{k}||$opts{n}||$opts{w}) ) {die "\n\tError: Poly trim settings require (-Y T)\n\n";}



#===== FILE AND DIRECTORY SETUP =====
print "\nChecking input file formats...";

# check file formats
my ($INTYPE, $atNum, $plusNum, $fastNum);
$plusNum = `grep -c '+' $INPATH`; $fastNum = `grep -c '>' $INPATH`; $atNum = `grep -c '\@' $INPATH`;
if ($atNum > 0 && $plusNum > 0) { $INTYPE = 'FASTQ'; $QUALPATH = 'FASTQ'; print "FASTQ detected.\n"; }
elsif ($atNum == 0 && $plusNum == 0 && $fastNum > 0) { $INTYPE = 'FASTA'; print "FASTA detected.\n"; }
else { die "\n\tError: File <$INPATH> not recognizable as FASTA or FASTQ... @ or + in FASTA headers?\n\n"; }

if ($QUALPATH eq 'none' && $QUALMIN ne 'F') { die "\n\tError: Quality trimming has been selected (-Q) but no quality file was provided (-q)\n\n"; }
if ($SPLIT ne 'F' && $INTYPE eq 'FASTA') { die "\n\tError: File splitting is currently only available for FASTQ formatted input files\n\n"; }

if ($opts{q} ne "") { if ($INTYPE eq 'FASTQ') { die "\n\tError: Why input -q with -f type FASTQ?? \n\n"; }} #else { &fastaCheck($QUALPATH, $QUALFILE); }}
if ($opts{v} ne "") { &fastaCheck($VECTORPATH, $VECTORFILE); }
if ($opts{s} ne "") { &fastaCheck($CONTAMPATH, $CONTAMFILE); }
if ($CLIPFILE eq 'Y') { &fastaCheck($CLIPSET, $CLIPSET); }
#if ($INTYPE eq 'FASTA') { &fastaCheck($INPATH, $INFILE); }

# set location of accessory programs
my ($seqDir, $tagDir) = ('seqclean-x86_64', 'tagdust');

# create output folder
if (-e "$OUTFILE/") { die "\n\tError: Directory <$OUTFILE> already exists in current directory.\n\n"; } 
else { system ("mkdir $dir/$OUTFILE"); system ("mkdir $dir/$OUTFILE/FinalOutput"); }
print "\n===== STARTING SnoWhite run <$OUTFILE> with file <$INFILE> =====\n";

# initiate log file
open INFO, ">$OUTFILE/$OUTFILE.log";
print INFO "Information for SnoWhite 2.0.x run <$OUTFILE>

===== INPUT PARAMETERS =====

	Files:
	-f: fasta or fastq sequences <$INPATH>
	-q: quality file <$QUALPATH>
	-v: vector/primer/adaptor file <$VECTORPATH>
	-s: internal/long contaminants file <$CONTAMPATH>
	
	Output settings:
	-o: output file prefix <$OUTFILE>
	-m: minimum sequence length for cleaned reads <$MINLENGTH>
	-g: delete all temporary (garbage) files <$DELG>	
	-R: convert final output to fastq format <$OUTQ>

	File splitting (FASTQ only):
	-B: split files <$SPLIT>
	-j: barcodes orientation <$LOOKJ>
	-z: number of mismatches allowed <$BMIS>
	
	Quality trimming:
	-Q: minimum phred score under which to trim 3' ends <$QUALMIN>

	End clipping:
	-E: clip at 3', 5', Both, or according to sequences in given FILENAME <$CLIPSET>
	-c: number of bases to clip off the front of all sequences <$CLIP>

	TagDust read filtering (for multimers of sequences in -v):
	-D: execute TagDust, assuming primer/adapter (-v) file is provided <$USETAG>
	-d: false discovery rate <$FDR>	

	SeqClean trimming (for matches to sequences in -v and -s):
	-L: execute SeqClean <$USESEQ>
	-p: processor number <$PROCESSORS>

	Terminal poly trimming (e.g. AAAAAAAAAACGATTAG...):
	-Y: execute poly trimming <$USEPOLY>
	-l: minimum length of terminal A/T repeat <$POLYLENGTH>
	-a: trim poly A at 3', 5', or Both ends <$LOOKA>
	-t: trim poly T at 3', 5', or Both ends <$LOOKT>

	Terminal poly trimming inside of cap (e.g. CGAAAAAAAAAAAACGATTAG...):
	-b: number of terminal bases to look beyond for start of terminal poly A/T <$CAPLENGTH>
	-r: minimum length of A/T repeat inside of -b to consider as poly A/T <$INSIDECAP>

	Internal poly trimming (e.g. ...CCGTATAGGAAAAAAAAAAAAAAAAAAAACGATTAGGG...):
	-i: minimum length of internal poly A/T repeat to consider as poly A/T <$INSIDEMAX>
	-k: keep the longer end of sequence broken by a single internal polyA/T? <$KEEPFRAG>

	General poly trimming settings:
	-n: interpret Ns within A/T repeats as As or Ts? <$NBAD>
	-w: allow wobble: ie. ignore single alternative bases within A/T repeats? <$WBAD>
	\n\n";
close INFO;


#===== SPLITTING =====
my (@workingList, @tempList, $type, @headers, @reads, @records);
if ($SPLIT eq 'F') { #no splitting, copy starting files into new directory
	print "\n===== READING FILE =====\n";  &printLog("\n===== READING FILE =====\n");
	if ($INTYPE eq 'FASTA') { 
		$type = 'nuc'; &readIn($INPATH); #read in file and remove any whitespace from headers
		open OUTA, ">$OUTFILE/inputFile"; for (my $i = 0; $i<@reads; $i++) { print OUTA "$headers[$i]\n$reads[$i]\n"; } close OUTA;
		(@reads, @headers) = ();
	}
	else { &readFastq($INPATH); open OUTQ, ">$OUTFILE/inputFile"; foreach (@records) { print OUTQ "$_\n"; } close OUTQ; @records = ();} #for FASTQ modify headers
	push @workingList, "$OUTFILE/inputFile"; #store location
	
	unless ($QUALPATH eq 'none' || $QUALPATH eq 'FASTQ') { 
		$type = 'qual'; &readIn($QUALPATH); #read in file and remove any whitespace from headers
		open OUTU, ">$OUTFILE/inputFile.qual"; for (my $i = 0; $i<@reads; $i++) { print OUTU "$headers[$i]\n$reads[$i]\n"; } close OUTU;
		(@reads, @headers) = ();
	}
}
else {
	print "\n===== SPLITTING =====\n";  &printLog("\n===== SPLITTING =====\n");
	if ($SPLITFILE eq 'Y') {  #split by barcode #http://code.google.com/p/ngopt/  
		print "\nSplitting file by barcodes...\n"; &printLog("\nSplitting file by barcodes...\n");
		if ($LOOKJ eq '5') { system ("cd Programs/; perl splitBC_Sno.pl ../$INPATH --bcfile ../$SPLIT --bol --mismatches $BMIS --prefix ../$OUTFILE/bc_ >>../$OUTFILE/$OUTFILE.log"); }
		else { system ("cd Programs/; perl splitBC_Sno.pl ../$INPATH --bcfile ../$SPLIT --eol --mismatches $BMIS --prefix ../$OUTFILE/bc_ >>../$OUTFILE/$OUTFILE.log");  }
		my @outfiles = `ls $OUTFILE/bc_*`; 
		foreach (@outfiles) { #save the new filenames and location 
			my $location;
			chomp $_; 
			if ($_ =~ m/^$OUTFILE/) { $location = $_; } #if the ls includes dir names
			else { $location = "$OUTFILE/$_"; } 
			my $lineNum = `wc -l < $location`;
			unless ($lineNum == 0) { 
				push @workingList, $location; #exclude empty files
				&readFastq($location); open OUTQ, ">$location"; foreach (@records) { print OUTQ "$_\n"; } close OUTQ; @records = (); #clean spaces out of header names
			}
		} 
	}
	else { #split by number of files
		print "\nSplitting input file...\n";  &printLog("\nSplitting input file...\n");
		&readFastq ($INPATH); #this subroutine substitutes spaces in the headers with "_spacehere_"
		my $numReads = scalar@records;
		my $part = int($numReads/$SPLIT); if ($part == 0) { die "\n\tError: Number of desired files for split exceeds the number of reads input\n\n"; }
		my @breaks; for (my $s = 1; $s < $SPLIT; $s++) { push @breaks, ($s*$part); }  push @breaks, (scalar@records); #set breakpoints
		my $marker = 0;
		foreach my $break (@breaks) {
			push @workingList, "$OUTFILE/$OUTFILE\_$break";
			open SPLITOUT, ">$OUTFILE/$OUTFILE\_$break";   
			for (my $m = $marker; $m < $break; $m++) { print SPLITOUT "$records[$m]";}
			close SPLITOUT;
			$marker = $break;
		}
		@records = ();
	}
}


#===== FASTQ to FASTA =====
unless ($INTYPE eq 'FASTA') {
	print "\n===== CONVERTING =====\n";  &printLog("\n===== CONVERTING =====\n");
	foreach my $thisFile (@workingList) {
		print "\nConverting <$thisFile> to FASTA...\n";  &printLog("\nConverting <$thisFile> to FASTA...\n");
		system ("cd Programs/; ./convert_project -f fastq -t fasta ../$thisFile ../$thisFile >>../$OUTFILE/$OUTFILE.log"); 
		push @tempList, "$thisFile.fasta";
		if ($DELG eq 'T') { system ("rm $thisFile"); }
	}
	@workingList = @tempList; @tempList = ();
	$QUALPATH = "FASTQ";
}
# convert_project will auto-detect offset (Sanger/newest Illumina offset is 33; previous Illumina phred and lod offset was 64)
# Illumina has started using a string of '2' scores to indicate low quality regions at the end of reads, ASCII coded as a string of Bs (becomes zeros in .qual conversion)
#TODO make rec in manual for SFF and SRA converters


#===== CLIPPING =====
my (@startClip, @endClip, $clipLength, $removed);
unless ($CLIP == 0 && $CLIPFILE eq 'N' && $QUALMIN eq 'F') {
	$removed = 0;
	print "\n===== CLIPPING =====\n"; &printLog("\n===== CLIPPING =====\n");
	#read in any clipping sequence info from file
	my (@clipLines, $startSeq, $endSeq);
	if ($CLIPFILE eq 'Y') {
		open CLIPIN, "<$CLIPSET"; while (<CLIPIN>) { chomp $_;  push @clipLines, $_; }  close CLIPIN;
		for (my $i = 0; $i < @clipLines; $i++) { 
			if ($clipLines[$i] =~ m/^>5_/) { $startSeq = $clipLines[$i+1]; }
			if ($clipLines[$i] =~ m/^>3_/) { $endSeq = $clipLines[$i+1]; }
		}
		unless ($startSeq || $endSeq) {die "\n\tError: tags not properly identified in clipping file (-E)\n\n"; }
	}

	foreach my $thisFile (@workingList) {
		(@reads, @headers, $type, @startClip, @endClip, $clipLength, $removed) = ();
		print "\nPerforming clipping of sequences in <$thisFile>...\n";

		#identify any 3' quality clipping
		unless ($QUALMIN eq 'F' || $QUALPATH eq 'none') {
			$type = 'qual';
			&readIn("$thisFile.qual");
			for (my $r = 0; $r < @reads; $r++) {
				my @values = split / /, $reads[$r];
				my $marker = $#values+1; #place a marker at the position where this and all subsequent values are below minimum quality
				for (my $v = $#values; $v >= 0; $v--) { if (($values[$v] < $QUALMIN) && ($v == $marker-1)) { $marker = $v; } else {last;}}
				$endClip[$r] = ($#values - $marker +1); #store the length of the clip
			}
			(@reads, @headers) = ();
		}

		#edit the sequence file
		$type = 'nuc';
		&readIn("$thisFile");
		for (my $i = 0; $i < @reads; $i++) { 
			#set clipping lengths on both ends
			if ($CLIPSET == 5 || $CLIPSET eq 'B') { $startClip[$i] = $CLIP; } 
			else {$startClip[$i] = 0;}

			if ($CLIPSET == 3 || $CLIPSET eq 'B') { if ($endClip[$i] ne "") { $endClip[$i] = max($CLIP, $endClip[$i]); }  else { $endClip[$i] = $CLIP; } }
			elsif ($QUALMIN eq 'F') {$endClip[$i] = 0;}
			
			if ($CLIPFILE eq 'Y') { 
				$startClip[$i] = rindex($reads[$i], $startSeq) + length($startSeq);
				if ($startClip[$i] < length($startSeq)) { $startClip[$i] = 0; } #if no match, -1 was returned

				my $endMatch = length($reads[$i]) - index($reads[$i], $endSeq);
				if ($endMatch == length($reads[$i]) + 1) { $endMatch = 0; } #if no match, -1 was returned
				if ($endClip[$i] ne "") { $endClip[$i] = max($endMatch, $endClip[$i]); } else {$endClip[$i]  = $endMatch;}
			}

			#clip or remove the read
			$clipLength = $startClip[$i] + $endClip[$i];
			if (length($reads[$i]) < ($clipLength+$MINLENGTH)) { delete($reads[$i]); $removed++; }
			else { 
				unless ($startClip[$i] == 0) { $reads[$i] = substr($reads[$i], $startClip[$i]); }
				unless ($endClip[$i] == 0) { $reads[$i] = substr($reads[$i], 0, -$endClip[$i]); }
			}
		}
		open OUT, ">$thisFile.clipped";
		for (my $i=0; $i<@reads; $i++) { if ($reads[$i] ne "") { print OUT "$headers[$i]\n$reads[$i]\n"; }}
		close OUT;
		push @tempList, "$thisFile.clipped";
		(@reads, @headers, @clipLines) = ();	

		#edit the quality file
		unless ($QUALPATH eq 'none') {
			$type = 'qual';
			&readIn("$thisFile.qual");
			for (my $i = 0; $i < @reads; $i++) {
				$clipLength = $startClip[$i] + $endClip[$i];
				my @temp = split / /, $reads[$i];
				if (scalar@temp < ($clipLength+$MINLENGTH)) { delete($reads[$i]); }
				else { 
					unless ($startClip[$i] == 0) { @temp = splice (@temp, $startClip[$i]);  $reads[$i] = join ' ', @temp; }
					unless ($endClip[$i] == 0) { @temp = splice (@temp, 0, -$endClip[$i]);  $reads[$i] = join ' ', @temp; }
				}
			}
			open OUT, ">$thisFile.clipped.qual";
			for (my $i=0; $i<@reads; $i++) { if ($reads[$i] ne "") { print OUT "$headers[$i]\n$reads[$i]\n"; }}
			close OUT;
			(@reads, @headers) = ();
			if ($DELG eq 'T') { system ("rm $thisFile.qual"); }
		}
		(@startClip, @endClip) = ();
		if ($DELG eq 'T') { system ("rm $thisFile"); }
	}
	@workingList = @tempList;  @tempList = ();
	open INFO, ">>$OUTFILE/$OUTFILE.log"; 
	if ($CLIPFILE eq 'N') { print INFO "\nAll sequences clipped <$CLIP> bases from <$CLIPSET> end(s)"; }
	else { print INFO "\nSequences clipped to sequence(s) in file <$CLIPSET>"; }
	print INFO "\nSequences less than $MINLENGTH bases after clipping: $removed\n\n\n"; 
	close INFO;
}


#===== TAGDUST =====
unless ($VECTORPATH eq 'none' || $USETAG eq 'F') {
	&printLog("\n===== TAGDUST =====\n");
	print "\n===== TAGDUST =====\n";

	foreach my $thisFile (@workingList) {
		print "\nPerforming TagDust cleaning for <$thisFile>...\n";  &printLog("\nPerforming TagDust cleaning for <$thisFile>...\n");

		#modify input file format
		my (@longHeaders, @longReads);
		(@reads, @headers) = ();
		$type = 'nuc';
		&readIn("$thisFile");
		open OUT, ">$thisFile";
		for (my $i = 0; $i < @reads; $i++) {
			if (length($reads[$i]) > 999) { push @longReads, $reads[$i];  push @longHeaders, $headers[$i]; }
			print OUT "$headers[$i]\n$reads[$i]\n"; 
		}
		close OUT;
		(@reads, @headers) = ();

		#run TagDust
		system ("cd Programs/$tagDir/; ./tagdust -fdr $FDR -o ../../$thisFile.tagdusted -a ../../$thisFile.tagdust_trash ../../$VECTORPATH ../../$thisFile 2>>../../$OUTFILE/$OUTFILE.log");

		#check for any long sequences that were cleared but truncated
		if (@longHeaders) {
			my $bookmark = 0;
			(@reads, @headers) = ();
			$type = 'nuc';
			&readIn("$thisFile.tagdusted");
			for (my $h = 0; $h < @longHeaders; $h++) {
				for (my $l = $bookmark; $l < @reads; $l++) {
					if ($headers[$l] =~ m/^$longHeaders[$h]/) { $reads[$l] = $longReads[$h];  $bookmark = $l;  last; }
				}
			}
			open OUT, ">$thisFile.tagdusted";
			for (my $i = 0; $i < @reads; $i++) { print OUT "$headers[$i]\n$reads[$i]\n"; }
			close OUT;

			my $longs = scalar@longHeaders;
			(@reads, @headers, @longReads, @longHeaders) = ();
			&printLog("\nSequences longer than 999 bp: $longs\n");
		}

		#edit tagDust output
		if (-e "$thisFile.tagdust_trash") {
			my @dustNames;
			open TDUST, "<$thisFile.tagdust_trash";
			while (<TDUST>) { if ($_ =~ m/^>/) { chomp $_; push @dustNames, $_; }}
			close TDUST;
			open TOUT, ">$thisFile.tagdust_trash";
			foreach (@dustNames) { print TOUT "$_\n"; }
			close TOUT; @dustNames = ();

			# trim quality file to match
			unless ($QUALPATH eq 'none') {
				print "Trimming the quality file to match TagDust output...\n";
				my (@goodNames, @qualLines, @qualNames);
				open GOOD, "<$thisFile.tagdusted";
				while (<GOOD>) { if ($_ =~ m/^>/) { chomp $_; $_ =~ s/\s.+//; push @goodNames, $_; }}
				close GOOD;

				push @qualLines, 'dummy_entry';
				open QUAL, "<$thisFile.qual";
				while(<QUAL>) { 
					chomp $_;
					if ($_ =~ m/^>/) { #if there's a header
						push @qualNames, (join ' ', @qualLines); #store the previous sequence
						@qualLines = ();
						push @qualLines, "$_\n"; #store the header for this sequence
					}
					else { push @qualLines, $_; } #store lines of the sequence
				}
				push @qualNames, (join ' ', @qualLines); #store the last sequence
				close QUAL;
				shift @qualNames;
				@qualLines = ();

				my $bookMark = 0;
				open OUT, ">$thisFile.tagdusted.qual";
				for (my $g = 0; $g < @goodNames; $g++) {
					for (my $n = $bookMark; $n < @qualNames; $n++) {
						if ($qualNames[$n] =~ m/^$goodNames[$g]/) {
							$qualNames[$n] =~ s/\s\s/\n/;
							print OUT "$qualNames[$n]\n";
							$bookMark = $n+1;
							last;
						}
					}
				}
				close OUT;
				(@goodNames, @qualNames) = ();
				if ($DELG eq 'T') { system ("rm $thisFile.qual"); }
			}

			&printLog("\n\n");
			if ($DELG eq 'T') { system ("rm $thisFile"); }
			push @tempList, "$thisFile.tagdusted";
		}
		else { die "\n\tError: TagDust did not finish properly. Check the $OUTFILE.log for more information\n\n"; }
	}
	@workingList = @tempList;  @tempList = ();
}


#===== SEQCLEAN ROUND 1 =====
unless ($USESEQ eq 'F') {
	print "\n===== SEQCLEAN ROUND 1 =====\n";
	&printLog("===== SEQCLEAN ROUND 1 =====\n");
	&runSeqclean;
}


#===== POLY A/T TRIMMING =====
my ($r, @trim, @seq, $alpha, $beta, $start, $end, $newStart, $newEnd);
my ($shortCount, $inTrashCount, $inTrimCount, $A5Count, $A3Count, $T5Count, $T3Count) = (0,0,0,0,0,0,0);
unless ($USEPOLY eq 'F') {
	&printLog("===== POLY A/T TRIMMING =====\n");

	foreach my $thisFile (@workingList) {
		print "\nPerforming poly trimming for <$thisFile>...\n"; &printLog("\nPerforming poly trimming for <$thisFile>...\n");

		# read in sequence file
		(@reads, @headers) = ();
		$type = 'nuc';
		&readIn("$thisFile");

		# initite report
		open REPORT, ">$thisFile.polytrim_report";
		print REPORT "ID\tNewStart\tNewEnd\tOldLength\tTrash?\tTrim?\n";
		close REPORT;

		# build an array (@trim) of hashes with trimming information
		($r, @trim, @seq, $alpha, $beta, $start, $end, $newStart, $newEnd) = ();
		($shortCount, $inTrashCount, $inTrimCount, $A5Count, $A3Count, $T5Count, $T3Count) = (0,0,0,0,0,0,0);
		for( $r = 0 ; $r < scalar(@reads) ; $r++ ) {
			@seq = split //, $reads[$r];
			$trim[$r]{bases} = scalar @seq;
			($trim[$r]{start},$trim[$r]{end},$trim[$r]{Xstart},$trim[$r]{Xend},$trim[$r]{Astart},$trim[$r]{Aend},$trim[$r]{Tstart},$trim[$r]{Tend}) = 0;

			# check for sequences that are already too short
			if (scalar @seq < $MINLENGTH) { $trim[$r]{fate} = 'short'; }

			else { 
				# check for terminal Xs (cross_match debris)
				my $counter = 0; # 5' end
				if ($seq[0] =~ m/X/) { 
					for (my $s = 0; $s < scalar(@seq); $s++) {
						if ($seq[$s] eq 'X') { $counter++ }
						else { last }
					}
					$trim[$r]{Xstart} = $counter;
				}

				$counter = 0; # 3' end
				if ($seq[$#seq] =~ m/X/) { 
					for (my $s = $#seq; $s >= 0; $s--) {
						if ($seq[$s] eq 'X') { $counter++ }
						else { last }
					}
					$trim[$r]{Xend} = $counter;
				}

				# update sequence
				unless ($trim[$r]{Xend} == 0) { @seq = splice (@seq,$trim[$r]{Xstart},-$trim[$r]{Xend}); }
				else { @seq = splice (@seq,$trim[$r]{Xstart}); }

				# check for terminal repeats
				# check 5' end
				if ($LOOKA eq 'B' || $LOOKA eq '5') {
					$alpha = 'A';
					if ($NBAD eq 'T') { $beta = 'N'; &fivePrime('Astart'); }
					else { $beta = 'A'; &fivePrime('Astart'); }
				}
				else {$trim[$r]{'Astart'} = 0;}
				if ($LOOKT eq 'B' || $LOOKT eq '5') {
					$alpha = 'T';
					if ($NBAD eq 'T') { $beta = 'N'; &fivePrime('Tstart'); }
					else { $beta = 'T'; &fivePrime('Tstart'); }
				}
				else {$trim[$r]{'Tstart'} = 0;}

				# check 3' end
				if ($LOOKA eq 'B' || $LOOKA eq '3') {
					$alpha = 'A';
					if ($NBAD eq 'T') { $beta = 'N'; &threePrime('Aend'); }
					else { $beta = 'A'; &threePrime('Aend'); }
				}
				else {$trim[$r]{'Aend'} = 0;}
				if ($LOOKT eq 'B' || $LOOKT eq '3') {
					$alpha = 'T';
					if ($NBAD eq 'T') { $beta = 'N'; &threePrime('Tend'); }
					else { $beta = 'T'; &threePrime('Tend'); }
				}
				else {$trim[$r]{'Tend'} = 0;}


				# pull out good portion of the sequence
				$start = max($trim[$r]{'Astart'}, $trim[$r]{'Tstart'});
				$end = max($trim[$r]{'Aend'}, $trim[$r]{'Tend'});
				unless ($end == 0) { @seq = splice (@seq,$start,-$end); }
				else { @seq = splice (@seq,$start); }
				my $seqString = join '', @seq;

				# check for internal repeats
				($newStart,$newEnd) = 0;
				if ($NBAD eq 'T') { $alpha = 'AN'; $beta = 'TN'; }
				else { $alpha = 'A'; $beta = 'T'; }
				if ( $seqString =~ m/([$alpha]{$INSIDEMAX})/ || $seqString =~ m/([$beta]{$INSIDEMAX})/) {
					if ($KEEPFRAG eq 'F') { $trim[$r]{fate} = 'internal'; }
					else { 
						if ($NBAD eq 'T') { ($alpha,$beta) = 'N'; }
						else { $alpha = 'A'; $beta = 'T'; }
						($newStart,$newEnd) = &findInternal;
					}
				}

				# trim sequence
				$trim[$r]{start} = $newStart + $start;
				$trim[$r]{end} = $newEnd + $end;
				unless ($newEnd == 0) { @seq = splice (@seq,$newStart,-$newEnd); }
				else { @seq = splice (@seq,$newStart); }

				# check for any additional internal repeats, minimum length, and print
				my $seqString = join '', @seq;
				$headers[$r] =~ s/\s.+//;
				if ($NBAD eq 'T') { $alpha = 'AN'; $beta = 'TN'; }
				else { $alpha = 'A'; $beta = 'T'; }
				if ( $seqString =~ m/([$alpha]{$INSIDEMAX})/ || $seqString =~ m/([$beta]{$INSIDEMAX})/) { $trim[$r]{fate} = 'internal'; }
				if (scalar@seq >= $MINLENGTH  &&  $trim[$r]{fate} ne 'internal') {
					open OUT, ">>$thisFile.nopoly";
					print OUT "$headers[$r]\n$seqString\n";
					close OUT;
				}
				elsif (scalar@seq < $MINLENGTH && $trim[$r]{fate} ne 'internal') { $trim[$r]{fate} = 'short'; }
			}

			# update start and end information for any X trimming
			if ($trim[$r]{Xstart} > 0) {$trim[$r]{start} = $trim[$r]{start} + $trim[$r]{Xstart}; }
			if ($trim[$r]{Xend} > 0) {$trim[$r]{end} = $trim[$r]{end} + $trim[$r]{Xend}; }

			# poly trimming report
			$headers[$r] =~ s/>//;
			my $pos5 = $trim[$r]{start} +1;
			my $pos3 = $trim[$r]{bases} - $trim[$r]{end};
			open REPORT, ">>$thisFile.polytrim_report";
			print REPORT "$headers[$r]\t$pos5\t$pos3\t$trim[$r]{bases}\t";
			if ($trim[$r]{fate}) {
				if ( $trim[$r]{fate} eq 'short' ) { print REPORT 'S'; $shortCount++ }
				if ( $trim[$r]{fate} eq 'internal') { print REPORT 'I'; $inTrashCount++ }
			}
			else { print REPORT 'no'; }
			print REPORT "\t";
			if ($trim[$r]{Xstart} > 0) {print REPORT 'X5 '; }
			if ($trim[$r]{Xend} > 0) {print REPORT 'X3 '; }
			if ($trim[$r]{Astart} > 0) {print REPORT 'A5 '; $A5Count++ }
			if ($trim[$r]{Aend} > 0) {print REPORT 'A3 '; $A3Count++ }
			if ($trim[$r]{Tstart} > 0) {print REPORT 'T5 '; $T5Count++ }
			if ($trim[$r]{Tend} > 0) {print REPORT 'T3 '; $T3Count++ }
			if ($trim[$r]{start} > max($trim[$r]{Astart}, $trim[$r]{Tstart})) { print REPORT 'I '; }
			if ($trim[$r]{end} > max($trim[$r]{Aend}, $trim[$r]{Tend})) { print REPORT 'I '; }
			if ($trim[$r]{start} == 0 && $trim[$r]{end} == 0) { print REPORT 'no'; }
			print REPORT "\n";
			close REPORT;
		}
		(@headers, @reads, @seq) = ();


		# tally the types of trimming, trashing in log file
		open INFO, ">>$OUTFILE/$OUTFILE.log"; 
		print INFO "===== POLY TRIMMING REPORT =====\n";
		if ($LOOKA eq 'B' || $LOOKA eq '5') { print INFO "5' polyA trimming: $A5Count sequence(s)\n"; }
		if ($LOOKA eq 'B' || $LOOKA eq '3') { print INFO "3' polyA trimming: $A3Count sequence(s)\n"; }
		if ($LOOKT eq 'B' || $LOOKT eq '5') { print INFO "5' polyT trimming: $T5Count sequence(s)\n"; }
		if ($LOOKT eq 'B' || $LOOKT eq '3') { print INFO "3' polyT trimming: $T3Count sequence(s)\n"; }
		if ($KEEPFRAG eq 'F') { print INFO "\nTrashed due to internal polyA/T over $INSIDEMAX bp: $inTrashCount sequence(s)\n"; }
		else { print INFO "\nInternal polyA/T trimming: $inTrimCount sequence(s)\n\n"; }
		print INFO "Trashed due to length shorter than $MINLENGTH bp: $shortCount sequence(s)\n\n";
		close INFO;

		if (-e "$thisFile.nopoly") { if ($DELG eq 'T') { system ("rm $thisFile"); } } 
		else { die "\n\tError: PolyTrimming did not finish properly. Check the $OUTFILE.log for more information\n\n"; }


		# update quality file
		unless ($QUALPATH eq 'none') {
			print "Trimming the quality file to match poly A/T trimming output...\n";	
			$type = 'qual';
			&readIn("$thisFile.qual");

			# edit the scores
			open QUALOUT, ">$thisFile.nopoly.qual";
			for (my $j = 0; $j < scalar(@reads); $j++) {
				unless ($trim[$j]{fate}) {
					print QUALOUT "$headers[$j]\n";
					my @scores = split / /, $reads[$j];
					if (scalar@scores != $trim[$j]{bases}) { die "\n\tError: Lengths do not match for sequence and quality entries\n\n"; }
					unless ($trim[$j]{end} == 0) { @scores = splice (@scores, $trim[$j]{start}, -$trim[$j]{end}); }
					else { @scores = splice (@scores, $trim[$j]{start}); }
					foreach (@scores) { print QUALOUT "$_ "; }
					print QUALOUT "\n";
				}
			}
			close QUALOUT;
			@reads = ();
			if ($DELG eq 'T') { system ("rm $thisFile.qual"); }
		}
		(@headers, @trim) = ();
		push @tempList, "$thisFile.nopoly";
	}
	@workingList = @tempList;  @tempList = ();
}


#===== SEQCLEAN ROUND 2 =====
unless ($USESEQ eq 'F') {
	print "\n===== SEQCLEAN ROUND 2 =====\n";
	&printLog("===== SEQCLEAN ROUND 2 =====\n");
	&runSeqclean;
}


#===== FASTA to FASTQ =====
unless ($OUTQ eq 'F') {
	foreach my $thisFile (@workingList) {
		print "\nConverting <$thisFile> to FASTQ...\n";
		system ("cd Programs/; ./convert_project -f fasta -t fastq ../$thisFile ../$thisFile >>../$OUTFILE/$OUTFILE.log"); 
		push @tempList, "$thisFile.fastq";
		if ($DELG eq 'T') { system ("rm $thisFile"); if (-e "$thisFile.qual") {system ("rm $thisFile.qual");} }
	}
	@workingList = @tempList; @tempList = ();
	$QUALPATH = 'none';
}


#===== FINAL OUTPUT =====
foreach my $thisFile (@workingList) {
	my @fileParts = split /\//, $thisFile; my $base = $fileParts[1];
	@fileParts = split /\./, $base; my $root = $fileParts[0];
	if ($root eq 'inputFile') { $root = $OUTFILE; }
	
	open OUTA, ">$OUTFILE/FinalOutput/$root.clean";
	open INA, "<$thisFile"; while (<INA>) { $_ =~ s/_spacehere_/ /g; print OUTA "$_"; }  close INA; close OUTA;  #read in file and remove any whitespace from headers
	if ($DELG eq 'T') { system ("rm $thisFile"); }
		
	unless ($QUALPATH eq 'none') { 
		open OUTU, ">$OUTFILE/FinalOutput/$root.clean.qual";
		open INU, "<$thisFile.qual"; while (<INU>) { $_ =~ s/_spacehere_/ /g; print OUTU "$_"; }  close INU; close OUTU;
		if ($DELG eq 'T') { system ("rm $thisFile.qual"); }
	}
}
&printLog("\n\n===== Snowhite complete =====\n");
print "\nSnowhite run $OUTFILE completed.\n\n";



#===== PAIRED END RESTORE ===== TODO? many potential combinations of header formats and read interleaving



#=======================
#===== SUBROUTINES =====
#=======================

sub printLog {
	my $info = $_[0];
	open INFO, ">>$OUTFILE/$OUTFILE.log"; print INFO "$info"; close INFO;
}

sub fastaCheck {
	my $path = $_[0];
	my $name = $_[1];
	my $fastaOK = `grep -c '^>' $path`;
	unless ($fastaOK > 0) { die "\n\tError: File <$name> does not appear to be in FASTA format.\n"; }
}


sub readIn {
	my (@fasta, @temps);
	open READS, "<$_[0]" || die "\n\tError: Can't open file <$_[0]>\n\n";
	while(<READS>) { chomp $_; $_ =~ s/  / /g; $_ =~ s/\s+$//; push @fasta , $_; }
	close READS;
	push( @fasta , 'END' );

	for( my $f = 0 ; $f < scalar(@fasta)-1 ; $f++ ) {
		if ( $fasta[$f] =~ m/^>/) { $fasta[$f] =~ s/\s/_spacehere_/g;  push @headers, $fasta[$f]; }
		elsif( ($fasta[$f + 1] =~ m/^>/) || ($fasta[$f + 1] =~ m/^END$/) ) {
			push @temps, $fasta[$f];
			if ($type eq 'qual') { push @reads , (join " ", @temps); }
			else { push @reads, (join "", @temps); }
			@temps = ();
		}
		else { push @temps, $fasta[$f]; }
	}

	(@fasta, @temps) = ();
}


sub readFastq {
	my $path = $_[0];
	my (@lines, $atLine, $plusLine, @seqParts, $seqLines, $seq, $qual);
	
	open READQ, "<$path"; 
	foreach (<READQ>) { chomp $_; push @lines, $_; } 
	close READQ;  #read in the file by record
	

	for (my $i =0; $i < @lines; $i++) {
		if (!$atLine && !$plusLine) { if ($lines[$i] =~ m/^@/) { $atLine = $lines[$i]; }  else {die"\n\tError: Invalid FASTQ format?\n\n";} }  #start of new record
		elsif ($atLine && !$plusLine) {
			if ($lines[$i] =~ m/^[ACGTRYSWKMBDHVN]+$/i) { push @seqParts, $lines[$i]; }  #nucleotide data line
			else { #should be quality header line
				if ($lines[$i] =~ m/^\+/) { $plusLine = $lines[$i]; $seqLines = scalar(@seqParts); $seq = join '', @seqParts; @seqParts = (); }  
				else {die"\n\tError: Invalid FASTQ format?\n\n";}  }  
		}
		elsif ($atLine && $plusLine) { #quality line
			push @seqParts, $lines[$i];
			if (scalar(@seqParts) == $seqLines) { #end of quality lines
				$qual = join '', @seqParts; 
				$atLine =~ s/\s/_spacehere_/g; $plusLine =~ s/\s/_spacehere_/g; #deal with whitespace in headers
				push @records, "$atLine\n$seq\n$plusLine\n$qual"; 
				(@seqParts, $atLine, $plusLine) = (); 
			}
		}
	}
	@lines = ();
}


sub fivePrime {
	my $counter;
	my $region = $_[0];
	for (my $c = 0; $c <= $CAPLENGTH; $c++) {
		if ( ($seq[$c] eq "$alpha") || ($seq[$c] eq "$beta") ) {
			$counter = 1;
			for (my $s = $c+1; $s < scalar(@seq); $s++) {
				if ( ($seq[$s] eq "$alpha") || ($seq[$s] eq "$beta") ) { $counter++ }
				elsif ( ($seq[$s+1] eq "$alpha") && ($seq[$s+2] eq "$alpha") && ($WBAD eq 'T') ) { $counter++ }
				else {
					if ( ($CAPLENGTH > 0) && (($seq[0] ne "$alpha") || ($seq[0] ne "$beta")) ) { 
						if ($counter >= $INSIDECAP) { $trim[$r]{$region} = ($counter+$c); }
						else { $trim[$r]{$region} = 0; }
					}
					else {
						if ($counter >= $POLYLENGTH) { $trim[$r]{$region} = $counter; }
						else { $trim[$r]{$region} = 0; }
					}
					$counter = ();
					last
			}	}
			last unless ($trim[$r]{$region} == 0)
		}
		else { $trim[$r]{$region} = 0; }
}	}


sub threePrime {
	my $counter;
	my $region = $_[0];
	for (my $c = $#seq; $c >= $#seq-$CAPLENGTH-1; $c--) {
		if ( ($seq[$c] eq "$alpha") || ($seq[$c] eq "$beta") ) {
			$counter = 1;
			for (my $s = $c-1; $s >= 0; $s--) {
				if ( ($seq[$s] eq "$alpha") || ($seq[$s] eq "$beta") ) { $counter++ }
				elsif ( ($seq[$s-1] eq "$alpha" && $seq[$s-2] eq "$alpha") && ($WBAD eq 'T') ) { $counter++ }
				else {
					if ( ($CAPLENGTH > 0) && ( ($seq[$#seq] ne "$alpha") || ($seq[$#seq] ne "$beta")) ) {
						if ($counter >= $INSIDECAP) { $trim[$r]{$region} = $counter + (scalar @seq - $c); }
						else { $trim[$r]{$region} = 0; }
					}
					else { 
						if ($counter >= $POLYLENGTH) { $trim[$r]{$region} = $counter; }
						else { $trim[$r]{$region} = 0; }
					}
					$counter = ();
					last
			}	}
			last unless ($trim[$r]{$region} == 0)
		}
		else { $trim[$r]{$region} = 0; }
}	}



sub findInternal {
	# find the longest repeat
	my ($Acounter, $Tcounter, $maxRun, $maxStart, $maxEnd) = 0;
	for (my $s = 0; $s < @seq; $s++) {
		if ( ($seq[$s] eq 'A') || ($seq[$s] eq "$alpha") ) { $Acounter++ }
		else { 
			if ($Acounter > $maxRun) { $maxRun = $Acounter; $maxEnd = $s; $maxStart = ($s-$Acounter)+1; $Acounter = 0; }
			else { $Acounter = 0; }
		}

		if ( ($seq[$s] eq 'T') || ($seq[$s] eq "$beta") ) { $Tcounter++ }
		else { 
			if ($Tcounter > $maxRun) { $maxRun = $Tcounter; $maxEnd = $s-1; $maxStart = $s-$Tcounter; $Tcounter = 0; }
			else { $Tcounter = 0; }
		}			
	}

	# find clipping amounts to give the largest fragment to either side
	if ($maxRun >= $INSIDEMAX) {
		$inTrimCount++;
		if ( $maxStart >= $#seq-$maxEnd ) { return(0,($#seq-$maxStart)); }
		else { return(($maxEnd+1),0); }
	}
	else { return(0,0); }
}



sub runSeqclean {
	foreach my $thisFile (@workingList) {
		print "\nPerforming a round of SeqClean for <$thisFile>...\n";

		# run seqclean
		unless ($VECTORPATH eq 'none') { system ("cp $VECTORPATH Programs/$seqDir/vectorfile"); system ("cd Programs/$seqDir/bin; ./formatdb -i ../vectorfile -p F"); }
		unless ($CONTAMPATH eq 'none') { system ("cp $CONTAMPATH Programs/$seqDir/contamfile"); system ("cd Programs/$seqDir/bin; ./formatdb -i ../contamfile -p F"); }

		if ($VECTORPATH eq 'none' && $CONTAMPATH eq 'none') { system ("cd Programs/$seqDir/; perl seqclean ../../$thisFile -l $MINLENGTH -c $PROCESSORS 2>>../../$OUTFILE/$OUTFILE.log"); }
		elsif ($VECTORPATH eq 'none') { system ("cd Programs/$seqDir/; perl seqclean ../../$thisFile -s contamfile -l $MINLENGTH -c $PROCESSORS 2>>../../$OUTFILE/$OUTFILE.log"); }
		elsif ($CONTAMPATH eq 'none') { system ("cd Programs/$seqDir/; perl seqclean ../../$thisFile -v vectorfile -l $MINLENGTH -c $PROCESSORS 2>>../../$OUTFILE/$OUTFILE.log"); }
		else { system ("cd Programs/$seqDir/; perl seqclean ../../$thisFile -v vectorfile -s contamfile -l $MINLENGTH -c $PROCESSORS 2>>../../$OUTFILE/$OUTFILE.log"); }
		&printLog("\n\n");

		my @fileParts = split /\//, $thisFile; my $base = $fileParts[1];
		# verify that output files were produced
		unless (-e "Programs/$seqDir/$base.cln" && -e "Programs/$seqDir/$base.clean" ) { 
			system ("mv Programs/$seqDir/err_seqcl_$base.log $OUTFILE/");
			system ("rm Programs/$seqDir/*.log");
			system ("rm Programs/$seqDir/$base*");
			unless ($VECTORPATH eq 'none') { system ("rm Programs/$seqDir/vectorfile*"); }
			unless ($CONTAMPATH eq 'none') { system ("rm Programs/$seqDir/contamfile*"); }
			die "\n\tError: Seqclean did not finish properly. Check the $OUTFILE.log and err_seqcl_$base.log for more information\n\n";
		}

		# trim quality file to match
		unless ($QUALPATH eq 'none') {
			print "Trimming the quality file to match Seqclean output...\n";
			system ("cd Programs/$seqDir/; perl cln2qual $base.cln ../../$thisFile.qual 2>>../../$OUTFILE/$OUTFILE.log");
			if (-e "$thisFile.qual.clean") { 
				system ("mv $thisFile.qual.clean $thisFile.clean.qual"); 
				if ($DELG eq 'T') { system ("rm $thisFile.qual"); }
			}
			else { 
				system ("mv Programs/$seqDir/$base.cln $thisFile.seqclean1_report");
				system ("mv Programs/$seqDir/$base.clean $OUTFILE/");
				system ("rm Programs/$seqDir/*.log");
				system ("rm Programs/$seqDir/$base*");
				die "\n\tError: Quality file could not be trimmed to match clean sequence file by Seqclean\n";
			}
		}
		&printLog("\n\n");

		# cleanup
		system ("mv Programs/$seqDir/$base.cln $thisFile.seqclean_report");
		system ("mv Programs/$seqDir/$base.clean $OUTFILE/");
		system ("mv Programs/$seqDir/err_seqcl_$base.log $OUTFILE/");
		system ("rm Programs/$seqDir/*.log");
		system ("rm Programs/$seqDir/$base*");
		unless ($VECTORPATH eq 'none') { system ("rm Programs/$seqDir/vectorfile*"); }
		unless ($CONTAMPATH eq 'none') { system ("rm Programs/$seqDir/contamfile*"); }
		if ($DELG eq 'T') { system ("rm $thisFile"); }
		push @tempList, "$thisFile.clean";
	}
	@workingList = @tempList;  @tempList = ();
}


