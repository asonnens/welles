/*
 
 Tagdust - a program to remove artifacts from next generation
 sequencing reads. 
 
 Released under GPL - see the 'COPYING' file   
 
 Copyright (C) 2009 Timo Lassmann <timolassmann@gmail.com>
 
 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
 
 Please send bug reports, comments etc. to:
 timolassmann@gmail.com
 */

#include "detect.h"

/* 
 Checks if a sequence is covered by library sequences. Return the fraction of residues covered by library sequences.  
*/

double test_sequence(char* test_seq,int* mers,int len,int seed_len,unsigned int mask)
{ 
	int tmp_code[MAX_LINE];
	int i,j;
	int c = 0;
	int f_old =0;
	unsigned int code[seed_len+2];
	
	for(i =0; i < len;i++){
		tmp_code[i] = 0;
	}
	for(i = 0; i < seed_len;i++){
		code[i] = 0;
		for(j = 0;j < seed_len;j++){
			if(i != j){
				code[i] = code[i] << 2;
				code[i] |= (int) test_seq[j];
			}
		}
	}
	/*for(i = 0; i < len;i++){
	 fprintf(stderr,"%c",test_seq[i]+65);
	 }
	 fprintf(stderr,"\n");*/
	for(i = seed_len;i <= len;i++){
		for(j = 0; j < seed_len-1;j++){
			//do stuff here....
			if(mers[code[j]>>5] & (1<<(code[j] & 0x1F))){
				//fprintf(stderr,"Hit at %d	%d\n",i-1,code[j]);
				if((i-1)- f_old >= seed_len){
					c += seed_len;
				}else{
					c += (i-1) - f_old;
				}
				f_old = (i-1);
				break;
			}
		}
		code[seed_len] = code[0];	
		for(j = 0; j < seed_len-1;j++){
			code[j] = code[j+1] << 2 | test_seq[i];
			code[j] &= mask;	
		}
		code[seed_len-1] = code[seed_len];
	}
	//fprintf(stderr,"Coverage: %d / %d \n",c,len);
	return (double)c / (double)len*RESOLUTION;
}

