/*
 
 Tagdust - a program to remove artifacts from next generation
 sequencing reads. 
 
 Released under GPL - see the 'COPYING' file   
 
 Copyright (C) 2009 Timo Lassmann <timolassmann@gmail.com>
 
 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
 
 Please send bug reports, comments etc. to:
 timolassmann@gmail.com
 */

#include "detect.h"
#include <ctype.h>
#define MIN(a, b) (a > b ? b : a)

/*
 
 Collects length and nucleotide composition of the input reads. Simultaneously counts how many sequences are covered by x,x+1 ... percent library sequences
 
 */

struct stats_dat* generate_background(struct stats_dat* sd,struct parameters* param)
{
	//const int nuc_code[26] = {0,0,1,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0};
	int len_distribution[MAX_LINE];
	char line[MAX_LINE];
	char tmp_seq[MAX_LINE];
	double* nuc_composition = 0;
	double* di_nucleotide_16 = 0;
	double* di_nucleotide_4 = 0;
	FILE *file;
	int i,j,c;
	int local_numseq = 0;
	int count = 0;
	int len = 0;
	
	int seq_p = 0;
	int set = 0;
	
	double sum = 0;
	int seed_len = param->mer_len;
	unsigned int mask = 0;
	for(i = 0; i < seed_len-1;i++){
		mask = mask << 2;
		mask |= 3; 
	}
	
	
	nuc_composition = malloc(sizeof(double)*4);
	
	di_nucleotide_16 = malloc(sizeof(double)*16);
	di_nucleotide_4  = malloc(sizeof(double)*16);
	
	for(i = 0;i < MAX_LINE;i++){
		len_distribution[i] = 0;
	}
	
	for(i = 0; i < 16;i++){
		di_nucleotide_16[i] = 0.0;
		di_nucleotide_4[i] = 0.0;
	}
	
	
	for(i = 0; i < 4;i++){
		nuc_composition[i] = 0.0;
	}
	for(c = 0; c < param->tag_files;c++){
	//if(1 == 1){
		local_numseq = 0;
		count = 0;
		len = 0;
		
		seq_p = 0;
		set = 0;
		
		
		
		if (!(file = fopen(param->tag_file[c], "r" ))){
			fprintf(stderr,"Cannot open query file '%s'\n", param->tag_file[c]);
		}
	
		while(fgets(line, MAX_LINE, file)){
			
			if(line[0] != '#'){
			
			if((line[0] == '@' && !set)|| (line[0] == '>' && !set)){
				if(local_numseq){
					len = len - param->trim3;
					tmp_seq[len] = 0;
				
					if(len >= seed_len){
						len_distribution[len]+=count;
						sd->p_counts[(int)test_sequence(tmp_seq,sd->mers,len,seed_len,mask)] += count; 
						for(i = 0;i < len;i++){
							nuc_composition[(int)tmp_seq[i]] += count;
						}
						for(i = 0;i < len-1;i++){
							di_nucleotide_16[(((int)(tmp_seq[i])<<2) | (int)tmp_seq[i+1])] += count;
						//	fprintf(stderr,"%d ",((int)(tmp_seq[i])<<2) |(int)(tmp_seq[i+1]));
						}
						//fprintf(stderr,"\n");
						
						
					}
					//fprintf(stderr,"%s\n%s\n",line,tmp_seq);
				}
				//fprintf(stderr,"%d	%d	%s\n%s\n",local_numseq,len,line,tmp_seq);
				seq_p = 1;
				set = 1;
				count = 1;
				if(param->ex_char){
					for(i = strlen(line);i >= 0;i--){
						if(line[i] == param->ex_char[0]){
							count = atoi(line+i+1);
							break;
						}
					}
				}
				if(len >= seed_len){
					local_numseq += count;
				}
				len = 0;
			}else if(line[0] == '+' && !set){
				seq_p = 0;
				set = 1;
			}else{			
				if(set){
					if(seq_p){
						for(i =  param->trim5;i < MAX_LINE;i++){
							if(iscntrl((int)line[i])){
								tmp_seq[len] = 0;
								break;
							}
							tmp_seq[len] = nuc_code[(int)line[i]];
							len++;
						}
					}
				}
				set = 0;
			}
			}
		}
		fclose(file);
		if(len >= seed_len){
			local_numseq+= count;
		}
		if(local_numseq){
			len = len - param->trim3;
			tmp_seq[len] = 0;
			if(len >= seed_len){
				len_distribution[len] += count;
				sd->p_counts[(int)test_sequence(tmp_seq,sd->mers,len,seed_len,mask)] += count;
				for(i = 0;i < len;i++){
					nuc_composition[(int)tmp_seq[i]] += count;
				}
				for(i = 0;i < len-1;i++){
					di_nucleotide_16[(((int)(tmp_seq[i])<<2) | (int)tmp_seq[i+1])] += count;
					//fprintf(stderr,"%d ",((int)(tmp_seq[i])<<2) |(int)(tmp_seq[i+1]));
				}
				//fprintf(stderr,"\n");
			}
		}
	}
	
	for(i = 0; i < 16;i++){
		di_nucleotide_4[i] = di_nucleotide_16[i];
	}
	for(i = 1; i < 16;i++){
		di_nucleotide_16[i] += di_nucleotide_16[i-1];
	}
	for(i = 0; i < 16;i++){
		di_nucleotide_16[i] /= di_nucleotide_16[15];
	}
	
	for(i = 0; i < 4;i++){
		for(j = 1;j < 4;j++){
			di_nucleotide_4[(i << 2) | j] += di_nucleotide_4[(i << 2) | (j-1)];
		}
	}
	
	for(i = 0; i < 4;i++){
		for(j = 0;j < 4;j++){
			di_nucleotide_4[(i << 2) | j] /= di_nucleotide_4[(i << 2) | 3];
		}
	}
	
	//for(i = 0; i < 16;i++){
	//	fprintf(stderr,"%d	%f	%f\n",i,di_nucleotide_16[i],di_nucleotide_4[i]);
	//}
	
	for(i = 1; i < 4;i++){
		nuc_composition[i] += nuc_composition[i-1];
	}
	for(i = 0; i < 4;i++){
		nuc_composition[i] /= nuc_composition[3];
	}
	
	
	if(param->model_order == 0){
		for(i = 0; i < param->rand;i++){
			for(j = MAX_LINE-1;j > 0;j--){
				if(len_distribution[j] != 0){
					sd->background = get_background(sd->background,sd->mers,nuc_composition,j,len_distribution[j],param->mer_len);
					fprintf(stderr,"%d	done	(%d)\n",j,len_distribution[j]); 
				}
			} 
		}
	}else if(param->model_order == 1){
		for(i = 0; i < param->rand;i++){
			for(j = MAX_LINE-1;j > 0;j--){
				if(len_distribution[j] != 0){
					sd->background = get_background_1(sd->background,sd->mers,di_nucleotide_16,di_nucleotide_4,j,len_distribution[j],param->mer_len);
					fprintf(stderr,"%d	done	(%d)\n",j,len_distribution[j]); 
				}
			} 
		}
		
	}
	for(i = 0;i < RESOLUTION;i++){
		sum += sd->background[i];
	}
	for(i = 0;i < RESOLUTION;i++){
		for(j = i+1; j < RESOLUTION;j++){
			sd->background[i] += sd->background[j];
		}
		sd->background[i]/=sum;
	}
	/*for(i = 0;i < RESOLUTION;i++){
		fprintf(stderr,"%d	%f\n",i,sd->background[i]);
	}*/
	
	free(di_nucleotide_16);
	free(di_nucleotide_4);
	
	free(nuc_composition);
	return sd;
}

/*
 Calculates p-values and applies the Benjamini-Hochberg method. 
 */


double fdr(double* background,int* p_counts,double fdr)
{
	double old_fdr = background[0];
	double correct = 0.0;
	double total_observations = 0;
	int i,j;
	for(i = 0;i < RESOLUTION;i++){
		total_observations += p_counts[i];
	}
	double c = 2;
	int accepted = 0;
	int rejected = 0;
	double found = 0;
	for(i = 0;i < RESOLUTION;i++){
		if(i ==0){
			for(j = 1;j < p_counts[i];j++){
				correct = MIN(background[i]*(total_observations/c),old_fdr);
				if(correct <= fdr){
					//				fprintf(stderr,"%d	%e\n",i,background[i]);
					found = i+1;
					break;
					
				}
				old_fdr = correct;
				c++;
			}
		}else{
			for(j = 0;j < p_counts[i];j++){
				correct = MIN(background[i]*(total_observations/c),old_fdr);
				if(correct <= fdr){
					//				fprintf(stderr,"%d	%e\n",i,background[i]);
					found = i+1;
					break;
				}
				old_fdr = correct;
				c++;
			}
		}
		if(found){
			found -= 1;
			break;
		}
		//	fprintf(stderr,"%d	correct:%f\n",i,correct);
	}
	if(found == 0){
		found = 100;
	}
	for(i = 0;i < found;i++){
		accepted+= p_counts[i];
	}
	for(i = found;i < RESOLUTION;i++){
		rejected += p_counts[i];
	}
	fprintf(stderr,"\n%d	Sequences\n%d	Tags rejected (%0.1f%%) at %0.1f%% coverage cutoff (%f FDR).\n\n",(int)total_observations,rejected,(double)rejected/total_observations*RESOLUTION,found,fdr);
	return found;
}


/*
 generates random sequences and complared them to the library sequences. 
 */


double* get_background(double* background,int* mers, double* nuc_composition,int len,int num,int seed_len)
{
	char tmp_seq[MAX_LINE];
	int i,j,c;
	double pick = 0.0;
	unsigned int mask = 0;
	for(i = 0; i < seed_len-1;i++){
		mask = mask << 2;
		mask |= 3; 
	}
	if(num < 100000){
		num = 100000;
	}
	
	for(i = 0;i < num;i++){
		for(j = 0;j < len;j++){
			pick = ran1(seed);
			for(c = 0;c < 4;c++){
				if(nuc_composition[c] > pick){
					tmp_seq[j] = c;
					break;
				}
			}
		}
		tmp_seq[len] = 0;
		background[(int)test_sequence(tmp_seq,mers,len,seed_len,mask)] +=1;		
	}
	return background;
} 

/*
 generates random sequences usind di-nucleotide fequencies  - not used in tagdust...  
 */

double* get_background_1(double* background,int* mers, double* nuc_composition16, double* nuc_composition4, int len,int num,int seed_len)
{
	char tmp_seq[MAX_LINE];
	int i,j,c;
	double pick = 0.0;
	unsigned int mask = 0;
	int left = 0;
	for(i = 0; i < seed_len-1;i++){
		mask = mask << 2;
		mask |= 3; 
	}
	if(num < 100000){
		num = 100000;
	}
	
	for(i = 0;i < num;i++){
		pick = ran1(seed);
		for(c =0; c < 16;c++){
			if(nuc_composition16[c] > pick){
				tmp_seq[0] = (c >> 2) & 0x3;
				tmp_seq[1] = c & 0x3;
				left = tmp_seq[1] << 2;
				break;
			}
		}
		
		for(j = 2;j < len;j++){
			pick = ran1(seed);
			for(c = 0;c < 4;c++){
				if(nuc_composition4[left | c] > pick){
					tmp_seq[j] = c;
					left = c << 2;
					break;
				}
			}			
		}
		
		
		/*for(j = 0;j < len;j++){
			pick = ran1(seed);
			for(c = 0;c < 4;c++){
				if(nuc_composition[c] > pick){
					tmp_seq[j] = c;
					break;
				}
			}
		}*/
		tmp_seq[len] = 0;
		background[(int)test_sequence(tmp_seq,mers,len,seed_len,mask)] +=1;		
	}
	return background;
} 



