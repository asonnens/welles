/*
 
 Tagdust - a program to remove artifacts from next generation
 sequencing reads. 
 
 Released under GPL - see the 'COPYING' file   
 
 Copyright (C) 2009 Timo Lassmann <timolassmann@gmail.com>
 
 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
 
 Please send bug reports, comments etc. to:
 timolassmann@gmail.com
 */

#include "detect.h"
#include <ctype.h>

static int numseq = 0;


int compare(const void* a, const void* b)
{
	int ai = *((int*)a), bi = *((int*)b);
	if(ai<bi)
		return -1;
	else if(ai>bi)
		return 1;
	else 
		return 0;
}


/*
 Reverses bits in an integer. Together with shifts and an '~' instructions this reverse complements sequenced in 2-bit encoding.
 */


unsigned int rev(unsigned int x)
{
	x = (x & 0x33333333) << 2 | (x & 0xCCCCCCCC) >> 2;
	x = (x & 0x0F0F0F0F) << 4 | (x & 0xF0F0F0F0) >> 4;
	x = (x & 0x00FF00FF) << 8 | (x & 0xFF00FF00) >> 8;
	x = (x & 0x0000FFFF) << 16 | (x  & 0xFFFF0000) >> 16;
	return x;
}


/*
 Reads in library sequences, converts them into lk-mers and stores them in bit-array mers
 */

int* create_library(int* mers,struct parameters* param)
{
	FILE *file;
	//const int nuc_code[26] = {0,0,1,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0};
	char line[MAX_LINE];
	char tmp_seq[MAX_LINE];
	int i = 0;
	int j = 0;
	//int count = 0;
	int len = 0;
	int seed_len = param->mer_len;
	
	unsigned int code[seed_len+2];
	unsigned int revcode; 
	unsigned int mask = 0;
	
	for(i = 0; i < seed_len-1;i++){
		mask = mask << 2;
		mask |= 3; 
	}
	
	
	if(!param->library_file){
		file = stdin;
		if (isatty(0)){
			//fprintf(stderr,"No STDIN..\n");
			return mers;
		}
	}else{
		if (!(file = fopen(param->library_file, "r" ))){
			fprintf(stderr,"Cannot open query file '%s'\n", param->raw_file);
			return mers;
		}
	}
	while(fgets(line, MAX_LINE, file)){
		if(line[0] == '>'){
			if(numseq){
				tmp_seq[len] = 0;
				if(len >= seed_len){
					for(i = 0; i < seed_len;i++){
						code[i] = 0;
						for(j = 0;j < seed_len;j++){
							if(i != j){
								code[i] = code[i] << 2;
								code[i] |= (int) tmp_seq[j];
							}
						}
					}
 					for(i = seed_len;i < len;i++){
						for(j = 0; j < seed_len-1;j++){
							//do stuff here....
							mers[code[j] >> 5] |= (1<< (code[j] & 0x1F));
							
							revcode = rev(code[j]);
							revcode = revcode >> (32 - ((seed_len-1) << 1));
							revcode = ~revcode;
							revcode &= mask;
							
							mers[revcode >> 5] |= (1<< (revcode & 0x1F));
						}
						code[seed_len] = code[0];	
						for(j = 0; j < seed_len-1;j++){
							code[j] = code[j+1]<< 2 | tmp_seq[i];
							code[j] &= mask;	
						}
						code[seed_len-1] = code[seed_len];
					}
				}else{
					fprintf(stderr,"Warning: a library sequence is shorter than the mer length. The sequence will not be considered '%s'\n%s\n",tmp_seq,line);
				}
			}
			numseq++;
			len = 0;
		}else{
			for(i = 0;i < MAX_LINE;i++){
				if(iscntrl((int)line[i])){
					tmp_seq[len] = 0;
					break;
				}
				//tmp_seq[len] = nuc_code[toupper(line[i])-65];
				tmp_seq[len] = nuc_code[(int)line[i]];
				len++;
			}
		}
	}
	
	if(numseq){
		tmp_seq[len] = 0;
		if(len >= seed_len){
			for(i = 0; i < seed_len;i++){
				code[i] = 0;
				for(j = 0;j < seed_len;j++){
					if(i != j){
						code[i] = code[i] << 2;
						code[i] |= (int) tmp_seq[j];
					}
				}
			}
			for(i = seed_len;i < len;i++){
				for(j = 0; j < seed_len-1;j++){
					//do stuff here....
					mers[code[j] >> 5] |= (1<< (code[j] & 0x1F));
					revcode = rev(code[j]);
					revcode = revcode >> (32 - ((seed_len-1) << 1));
					revcode  =  ~revcode;
					revcode &= mask;
					mers[revcode >> 5] |= (1<< (revcode & 0x1F));
				}
				code[seed_len] = code[0];	
				for(j = 0; j < seed_len-1;j++){
					code[j] = code[j+1]<< 2 | tmp_seq[i];
					code[j] &= mask;	
				}
				code[seed_len-1] = code[seed_len];
			}
		}	
	}
	
	fclose(file);
	return mers;
}

/*
 Reads in sequenced reads, scans them against library patters and rejects them as artifacts if they are covered by ..
 */

void check_tags_library(int* mers,struct parameters* param)
{
	FILE *file = NULL;
	FILE *fout = NULL;
	FILE *fout2 = NULL;
	//const int nuc_code[26] = {0,0,1,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0};
	char line[MAX_LINE];
	char tmp_seq[MAX_LINE];
	char tmp_qual[MAX_LINE];
	char tmp_seq_norm[MAX_LINE];
	char tmp_name[MAX_LINE];
	int i = 0;
	int c = 0;
	int count = 0;
	int len = 0;
	int qual_len = 0;
	int seed_len = param->mer_len;
	int local_numseq = 0;
	unsigned int mask = 0;
	int rejected = 0;
	
	int seq_p = 0;
	int set = 0;
	
	
	for(i = 0; i < seed_len-1;i++){
		mask = mask << 2;
		mask |= 3; 
	}
	
	
	
	
	if(param->artifact_file){
		if(!strcmp(param->artifact_file,"STDOUT")){
			fout = stdout; 
		}else{
			if ((fout = fopen(param->artifact_file, "w")) == NULL){
				fprintf(stderr,"can't open output\n");
				exit(0);
			}
		}
	}
	
	if(param->outfile){
		if(!strcmp(param->outfile,"STDOUT")){
			fout2 = stdout; 
		}else{
			if ((fout2 = fopen(param->outfile, "w")) == NULL){
				fprintf(stderr,"can't open output\n");
				exit(0);
			}
		}
	}else{
		fout2 = stdout;
	}
	
	//if( 0 == 0){ 
	//fprintf(stderr,"%d num\n",param->tag_files);
	for(c = 0; c < param->tag_files;c++){
		count = 0;
		len = 0;
		qual_len = 0;
		local_numseq = 0;
		//rejected = 0;
		
		seq_p = 0;
		set = 0;
		
		
		if (!(file = fopen(param->tag_file[c], "r" ))){
			fprintf(stderr,"Cannot open query file '%s'\n", param->tag_file[c]);
		}
	
		//fprintf(stderr," opened query file '%s'\n", param->tag_file[c]);

		while(fgets(line, MAX_LINE, file)){
			//if(line[0] != '#'){
			if((line[0] == '@' && !set)|| (line[0] == '>' && !set)){
				if(local_numseq){
					len = len-param->trim3;
					tmp_seq[len] = 0;
					tmp_seq_norm[len] = 0;
					qual_len = qual_len - param->trim3;
					tmp_qual[qual_len] = 0;
					if(len >= seed_len){
						if(test_sequence(tmp_seq,mers,len,seed_len,mask) >= param->cutoff){
							if(param->artifact_file){
								//fprintf(fout,"%s\n%s\n",tmp_name,tmp_seq_norm);
							
								print_seq(fout,tmp_name,tmp_seq_norm,tmp_qual,param->fasta);
							
							}
							rejected += count;
						}else if(param->outfile){
							//fprintf(fout2,"%s\n%s\n\n",tmp_name,tmp_seq_norm);
							print_seq(fout2,tmp_name,tmp_seq_norm,tmp_qual,param->fasta);
						}
					}
					//fprintf(stderr,"%s\n%s\n%s\n\n",tmp_name,tmp_seq_norm,tmp_qual ) ;
					//exit(0);
				}
			
				for(i = 0;i < strlen(line);i++){
					if(iscntrl((int)line[i])){
						tmp_name[i]= 0;
						break;
					}
					tmp_name[i] = line[i];
				}
				tmp_name[i] = 0;
								//fprintf(stderr,"%d	%d	%s\n%s\n",local_numseq,len,line,tmp_seq);
				seq_p = 1;
				set = 1;
				count = 1;
				if(param->ex_char){
					for(i = strlen(line);i >= 0;i--){
						if(line[i] == param->ex_char[0]){
							count = atoi(line+i+1);
							break;
						}
					}
				}
				//if(len >= seed_len){
					local_numseq += count;
				//}
				//fprintf(stderr,"First name : %s	count:%d	local:%d\n",tmp_name,count,local_numseq);

				len = 0;
				qual_len = 0;
			}else if(line[0] == '+' && !set){
				seq_p = 0;
				set = 1;
			}else{			
				if(set){
					if(seq_p){
						for(i = param->trim5;i < MAX_LINE;i++){
							if(iscntrl((int)line[i])){
								tmp_seq[len] = 0;
								tmp_seq_norm[len] = 0;
								break;
							}
							tmp_seq_norm[len] = line[i];
							//tmp_seq[len] = nuc_code[toupper(line[i])-65];
							tmp_seq[len] = nuc_code[(int)line[i]];
							len++;
						}
					}else{
						for(i = param->trim5;i < MAX_LINE;i++){
							if(iscntrl((int)line[i])){
								tmp_qual[qual_len] = 0;
								break;
							}
							tmp_qual[qual_len] = line[i];
							qual_len++;
						}
					}
				}
				set = 0;
				//fprintf(stderr,"%s\n%s\n%s\n\n",tmp_name,tmp_seq_norm,tmp_qual ) ;
			}
			//}
		}
		fclose(file);
	
		if(len >= seed_len){
			local_numseq+= count;
		}
	
		if(local_numseq){
		
			len = len - param->trim3;
			tmp_seq[len] = 0;
			tmp_seq_norm[len] = 0;
			qual_len = qual_len - param->trim3;
			tmp_qual[qual_len] = 0;
			if(len >= seed_len){
				if(test_sequence(tmp_seq,mers,len,seed_len,mask) >= param->cutoff){
					if(param->artifact_file){
						//fprintf(fout,"%s\n%s\n",tmp_name,tmp_seq_norm);
					
						print_seq(fout,tmp_name,tmp_seq_norm,tmp_qual,param->fasta);
						
					}
					rejected += count;
				}else if(param->outfile){
					//fprintf(fout2,"%s\n%s\n\n",tmp_name,tmp_seq_norm);
					print_seq(fout2,tmp_name,tmp_seq_norm,tmp_qual,param->fasta);
				}
			}
			//fprintf(stderr,"%s\n%s\n",line,tmp_seq);
		}
		//fclose(file);
	}
	
	if(param->artifact_file){
		fclose(fout);
	}
	if(param->outfile){
		fclose(fout2);
	}
	
	
	
	//fprintf(stderr,"\n%d	Sequences\n%d	Tags rejected (%0.1f%%) at %0.1f%% cutoff.\n\n",local_numseq,rejected,(double)rejected/(double)local_numseq*100.0,param->cutoff);
	
}

void print_seq(FILE *f,char* name,char*seq,char* qual, int fasta)
{
	int i = 0;
	int j = 0;
	
	if(qual[0] != 0 && !fasta){
		fprintf(f,"%s\n",name);
		i = 0;
		j = 0;
		while(seq[i]){
			if(linewrap){
			if(j ==60){
				fprintf(f,"\n");
				j = 0;
			}
			}
			fprintf(f,"%c",seq[i]);
			i++;
			j++;
		}
		fprintf(f,"\n");
		name[0] = '+';
		fprintf(f,"%s\n",name);
		i = 0;
		j = 0;
		while(qual[i]){
			if(linewrap){
			if(j ==60){
				fprintf(f,"\n");
				j = 0;
			}
			}
			fprintf(f,"%c",qual[i]);
			i++;
			j++;
		}
		fprintf(f,"\n");	
	}else if(qual[0] != 0 && fasta){
		name[0] = '>';
		fprintf(f,"%s\n",name);
		while(seq[i]){
			if(linewrap){
			if(j ==60){
				fprintf(f,"\n");
				j = 0;
			}
			}
			fprintf(f,"%c",seq[i]);
			i++;
			j++;
		}
		fprintf(f,"\n");
	}else{
		fprintf(f,"%s\n",name);
		while(seq[i]){
			if(linewrap){
			if(j ==60){
				fprintf(f,"\n");
				j = 0;
			}
			}
			fprintf(f,"%c",seq[i]);
			i++;
			j++;
		}
		fprintf(f,"\n");
	}
}

