/*
 
 Tagdust - a program to remove artifacts from next generation
 sequencing reads. 
 
 Released under GPL - see the 'COPYING' file   
 
 Copyright (C) 2009 Timo Lassmann <timolassmann@gmail.com>
 
 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
 
 Please send bug reports, comments etc. to:
 timolassmann@gmail.com
 */

#include "detect.h"

#define OPT_EX_CHAR 1
#define OPT_RAND 2
#define OPT_TRIM5 3
#define OPT_TRIM3 4
#define OPT_FASTA 5
#define OPT_MODEL 6

struct parameters* interface(struct parameters* param,int argc, char **argv)
{
	int c;
	int help = 0;
	static char version[] = VERSION;
	static char  usage[] =", Copyright (C) 2009 Timo Lassmann <timolassmann@gmail.com>\n";
	static char help_text[] = "\nUsage: tagdust [options]  lib.fa read1.fa read2.fa ...\n\
	\n\n\
	Options:\n\
	-f, -fdr	False discovery rate (default: 0.01)\n\
	-o <file>	print clean tags to file.\n\
	-a <file>	print artifactual tags to file.\n\
	-trim5 <X>	trim 'X' residues from the start of all reads.\n\
	-trim3 <X>	trim 'X' residues from the end of all reads.\n\
	-fasta		output format is fasta.\n\
	-s, -singleline	sequences are written in a single line.\n\
	-q, -quiet	quite mode\n\n\
	Identifies tags as artifactual sequences if they match to library sequences.\n\
	Library sequences must be in fasta; tag sequences in either fasta or fastq format.\n\
	";
	
	//-m		use 1st order markov model to generate background sequences.\n
	
	param = malloc(sizeof(struct parameters));
	param->quiet_flag  = 0;
	param->raw_file = 0;
	param->tag_file = 0;
	param->library_file = 0;
	param->artifact_file = 0;
	param->mer_len = 12;
	param->cutoff = 200.0;
	param->fdr = 0.01;
	param->outfile = 0;
	param->rand = 1;
	param->ex_char = 0;///"_";
	param->trim5 = 0;
	param->trim3 = 0;
	param->fasta = 0;
	param->model_order = 0;
	param->linewrap = 1;
	
	//opterr = 0;
	
	while (1){	
		static struct option long_options[] ={
			{"rand",required_argument,0,OPT_RAND},
			{"expression-char",required_argument,0,OPT_EX_CHAR},
			{"expression_char",required_argument,0,OPT_EX_CHAR},
			{"model",0,0,OPT_MODEL},
			{"trim5",required_argument,0,OPT_TRIM5},
			{"trim3",required_argument,0,OPT_TRIM3},
			{"fasta",0,0,OPT_FASTA},
			{"fdr",required_argument,0,'f'},
			{"help",0,0,'h'},
			{"quiet",required_argument,0,'q'},
			{"singleline",0,0,'s'},
			{0, 0, 0, 0}
		};
		
		int option_index = 0;
		c = getopt_long_only (argc, argv,"f:a:c:o:qshm:",long_options, &option_index);
		
		if (c == -1){
			break;
		}
		
		switch(c) {
			case 0:
				break;
				
			case OPT_MODEL:
				param->model_order = 1;
				break;
			case OPT_TRIM5:
				if(optarg[0] == '-'){
					fprintf(stderr,"option -trim5 requires an argument\n");
					exit(1);
				}
				param->trim5 = atoi(optarg);
				break;
			case OPT_TRIM3:
				if(optarg[0] == '-'){
					fprintf(stderr,"option -trim3 requires an argument\n");
					exit(1);
				}
				param->trim3 = atoi(optarg);
				break;
				
				
			case OPT_EX_CHAR:
				if(optarg[0] == '-'){
					fprintf(stderr,"option -expression-char requires an argument\n");
					exit(1);
				}
				param->ex_char = optarg;
				break;
			case OPT_RAND:
				if(optarg[0] == '-'){
					fprintf(stderr,"option -expression-char requires an argument\n");
					exit(1);
				}
				param->ex_char = optarg;
				break;
			/*case 'c':
				if(optarg[0] == '-'){
					fprintf(stderr,"option -c requires an argument\n");
					exit(1);
				}
				param->cutoff = atof(optarg);
				break;*/
				
			case OPT_FASTA:
				param->fasta = 1;
				break;
			case 'o':
				if(optarg[0] == '-'){
					fprintf(stderr,"option -o requires an argument\n");
					exit(1);
				}
				param->outfile = optarg;
				break;
			case 's':
				param->linewrap = 0;
				break;
			case 'f':
				if(optarg[0] == '-'){
					fprintf(stderr,"option -f requires an argument\n");
					exit(1);
				}
				param->fdr = atof(optarg);
				break;
			case 'a':
				if(optarg[0] == '-'){
					fprintf(stderr,"option -a requires an argument\n");
					exit(1);
				}
				param->artifact_file = optarg;
				break;
			case 'q':
				param->quiet_flag = 1;
				break;
			case 'm':
				param->mer_len = atoi(optarg);
				break;
			case 'h':
				help = 1;
				break;
			case '?':
				exit(1);
				break;
			default:
				fprintf(stderr,"default\n\n\n\n");
				abort ();
		}
	}
	
	fprintf(stderr,"%s%s",version,usage);
	if(help){
		fprintf(stderr,"%s\n",help_text);
		free(param);
		exit(0);
	}
	
	
	//fprintf(stderr,"5:%d	3:%d\n",param->trim5,param->trim3);
	//if(param->mer_len > 12){
	//	fprintf(stderr,"Maximum mer length is 12!\n");
	//	param->mer_len = 12;
	//}
	//fprintf(stderr,"MODE:%d\n",param->light);
	
	param->tag_file = malloc(sizeof(char*)* (argc-optind));
	
	param->library_file =  argv[optind++];
	
	c = 0;
	while (optind < argc){
		param->tag_file[c] = argv[optind++];
		c++;
	}
	param->tag_files = c;
	
	/*fprintf(stderr,"%s\n",param->library_file);
	for(c = 0; c < param->tag_files;c++){
		fprintf(stderr,"%d	%s\n",c,param->tag_file[c]);
	}*/
		
	
	if(param->quiet_flag){
		fclose(stderr);
	}
	if(!param->raw_file && !param->library_file){
		fprintf(stderr,"%s\n",help_text);
		free(param);
		exit(0);
	}
	if(!param->tag_file){
		fprintf(stderr,"%s\n",help_text);
		free(param);
		exit(0);
	}
	return param;
}
