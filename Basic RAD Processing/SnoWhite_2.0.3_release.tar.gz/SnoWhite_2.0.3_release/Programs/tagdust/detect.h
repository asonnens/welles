/*
 
 Tagdust - a program to remove artifacts from next generation
 sequencing reads. 
 
 Released under GPL - see the 'COPYING' file   
 
 Copyright (C) 2009 Timo Lassmann <timolassmann@gmail.com>
 
 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
 
 Please send bug reports, comments etc. to:
 timolassmann@gmail.com
 */

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <limits.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <pthread.h>

#include <assert.h>

#define MAX_LINE 1000
#define RESOLUTION 100


#define VERSION "TagDust version 1.13"

struct parameters{
	char* raw_file;
	char** tag_file;
	char* library_file;
	char* ex_char;
	char* outfile;
	char* artifact_file;
	double cutoff;
	double fdr;
	int tag_files;
	int rand;
	int mer_len;
	int quiet_flag;
	int trim5;
	int trim3;
	int fasta;
	int model_order;
	int linewrap;
};

struct stats_dat{
	double* background;
	int* mers;
	int *p_counts;
};

int nuc_code[255]; 

int *seed;

int linewrap;

void init_nuc_code();

int* create_library(int* mers,struct parameters* param);
void check_tags_library(int* mers,struct parameters* param);

double test_sequence(char* test_seq,int* mers,int len,int seed_len,unsigned int mask);

struct stats_dat* generate_background(struct stats_dat* sd,struct parameters* param);
double* get_background(double* background,int* mers, double* nuc_composition,int len,int num,int seed_len);

double* get_background_1(double* background,int* mers, double* nuc_composition16, double* nuc_composition4, int len,int num,int seed_len);

double fdr(double* background,int* p_counts,double fdr);

double ran1(int *idum);

unsigned int rev(unsigned int x);

struct parameters* interface(struct parameters* param,int argc,char **argv);

void print_seq(FILE *f,char* name,char*seq,char* qual, int fasta);
