/*

 Tagdust - a program to remove artifacts from next generation
 sequencing reads. 
 
 Released under GPL - see the 'COPYING' file   
 
 Copyright (C) 2009 Timo Lassmann <timolassmann@gmail.com>
 
 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.

 Please send bug reports, comments etc. to:
 timolassmann@gmail.com
*/
 
#include "detect.h"
#include "sys/time.h"


int main (int argc, char * argv[]) {
	struct parameters* param = 0;
	time_t start = 0;
	time_t end = 0;
	double time_param = 0;
	struct timeval tv1,tv2;
	struct timezone tz1,tz2;
	int i;
	int mer_hash_size = 0;
	
	int nseed = -1 * time(NULL);
	
	init_nuc_code();
	
	seed=(&nseed);
	
	gettimeofday(&tv1,&tz1);
	start = clock();
	param = interface(param,argc, argv);
	
	
	if(!param->linewrap){
		linewrap = 0;
	}else{
		linewrap = 1;
	}
	
	struct stats_dat* sd = 0;
	sd = malloc(sizeof(struct stats_dat));
	
	mer_hash_size = 4;
	for(i = 0; i < (param->mer_len-1);i++){
		mer_hash_size *= 4;
	}
	mer_hash_size /= 32 ;
	sd->mers = malloc(sizeof(int)* mer_hash_size);
	for(i = 0; i < mer_hash_size;i++){
		sd->mers[i] = 0;
	}
		
	sd->p_counts = malloc(sizeof(int)*(RESOLUTION));
	sd->background = malloc(sizeof(double)*RESOLUTION);
	for(i = 0;i < RESOLUTION;i++){
		sd->p_counts[i] = 0;
		sd->background[i] = 0.0;
	}		
	fprintf(stderr,"Creating Library\n");
	create_library(sd->mers,param);
	fprintf(stderr,"Generating Background\n");
	sd = generate_background(sd,param);
		
	if(param->fdr){
		param->cutoff = fdr(sd->background,sd->p_counts,param->fdr);
	}
	
	if(param->outfile || param->artifact_file){
		check_tags_library(sd->mers,param);
	}
	free(sd->mers);
	free(sd->background);
	free(sd->p_counts);
	free(sd);
	//target = get_fasta(target,param->infile[0]);
	//free(mers);
	free(param->tag_file);
	free(param);
	end = clock();
	time_param = (double)(end-start)/CLOCKS_PER_SEC;
	gettimeofday(&tv2,&tz2);
	fprintf(stderr,"\n	Elapsed time:\n");
	fprintf(stderr,"	%7.0ld seconds (%0.2lf CPU+SYS seconds)\n",((tv2.tv_sec - tv1.tv_sec)  ),time_param);
	
	return 0;
}

void init_nuc_code()
{
	int i;
	for(i = 0;i < 256;i++){
		nuc_code[i] = 0;
	}
	//small case: 
	nuc_code[67] = 1;
	nuc_code[71] = 2;
	nuc_code[84] = 3;
	//large case:  
	nuc_code[99] = 1;
	nuc_code[103] = 2;
	nuc_code[116] = 3;
	// color space: 
	nuc_code[49] = 1;
	nuc_code[50] = 2;
	nuc_code[51] = 5;				  
	
}

